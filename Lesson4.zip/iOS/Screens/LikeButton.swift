//
//  Like.swift
//  iOS
//
//  Created by Лолита Чернышева on 04.01.2020.
//  Copyright © 2020 Лолита Чернышева. All rights reserved.
//

import UIKit

class LikeButton: UIButton {
    override var isSelected: Bool {
        didSet 
    }
    
}
