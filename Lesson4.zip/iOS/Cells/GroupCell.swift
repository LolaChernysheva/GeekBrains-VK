import UIKit
class GroupCell: UITableViewCell {
    
    @IBOutlet weak var groupname: UILabel!
    @IBOutlet weak var groupavatar: UIImageView!
}
