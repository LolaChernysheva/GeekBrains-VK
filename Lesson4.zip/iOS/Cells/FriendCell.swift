import UIKit

class FriendCell: UITableViewCell {
    
    @IBOutlet weak var username: UILabel!
    @IBOutlet weak var avatar: UIImageView!
    @IBOutlet weak var shadowAvatar: AvatarView!
}
