//
//  ResponseGetUserPhotos.swift
//  iOS
//
//  Created by Лолита on 22.05.2020.
//  Copyright © 2020 Лолита Чернышева. All rights reserved.
//

import Foundation
import RealmSwift

class VKResponseGetUserPhotos: Object, Decodable {
     @objc dynamic let response: ResponseGetPhoto
}
class ResponseGetPhoto: Object,  Decodable {
   @objc dynamic let items: [PhotoList]
   @objc dynamic let text: String!
}
class PhotoList: Object, Decodable {
  @objc dynamic  let album_id: Int
  @objc dynamic  let date: Int
  @objc dynamic  let id: Int
   @objc dynamic let owner_id: Int
   @objc dynamic let has_tags: Bool
   @objc dynamic let post_id: Int
   @objc dynamic let sizes: [Sizes]
}
class Sizes: Object,  Decodable {
   @objc dynamic let height: Int
    @objc dynamic let url: String
   @objc dynamic let type: String
   @objc dynamic let width: Int
}
