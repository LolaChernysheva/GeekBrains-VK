//
//  Responses.swift
//  iOS
//
//  Created by Лолита on 21.05.2020.
//  Copyright © 2020 Лолита Чернышева. All rights reserved.
//

import Foundation
import Alamofire
import RealmSwift

class VKResponse: Object, Decodable {
   @objc dynamic let response: Response
    
}
//https://api.vk.com/method/groups.search?v=5.103&access_token=d63d0298ece8d218b0ca0b5db757d848b508d2986b74569e34d28b904be9b4cd2d75cffa8a2b9d3a74bf9&q=text&count=3
class Response: Object, Decodable {
   @objc dynamic let count: Int
   @objc dynamic let items: [UserGroup]
}

class UserGroup: Object, Decodable {
  @objc dynamic  let id: Int
  @objc dynamic  let name: String
  @objc dynamic  let screen_name: String
   @objc dynamic let is_closed: Int
   @objc dynamic let type: String
   @objc dynamic let is_admin: Int
   @objc dynamic let is_member: Int
   @objc dynamic let is_advertiser: Int
   @objc dynamic let photo_50: String
   @objc dynamic let photo_100: String
   @objc dynamic let photo_200: String
}








