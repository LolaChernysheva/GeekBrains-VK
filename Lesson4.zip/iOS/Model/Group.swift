//
//  Group.swift
//  iOS
//
//  Created by Лолита Чернышева on 24.12.2019.
//  Copyright © 2019 Лолита Чернышева. All rights reserved.
//
import Foundation
struct Group {
    var name: String
    var numberOfUsers: Int
    var groupAvatar: String
}
